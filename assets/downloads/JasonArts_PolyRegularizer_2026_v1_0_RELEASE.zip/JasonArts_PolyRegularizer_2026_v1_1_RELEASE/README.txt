JasonArts Poly Regularizer 2026 v1.1
www.jasonarts.com

For 3ds Max 2026 / Editable Poly objects.

Created/maintained by JasonArts.
Based on / inspired by GARP's "Edge Loop Regularizer" v1.1 from April 2011.
Modernized and expanded for newer 3ds Max polygon-selection workflows.

Included files:
- JasonArts_PolyRegularizer_2026_v1_1.mcr
  Toolbar macro version. Place this in your 3ds Max usermacros folder to install manually.

- JasonArts_PolyRegularizer_2026_v1_1.ms
  Source/readable MaxScript version for review or manual running.

- JasonArts_PolyRegularizer_2026_v1_1.mzp
  Optional drag-and-drop installer package. Some studios/IT departments block MZP files.

Manual install:
1. In 3ds Max, open MAXScript Listener and run: getDir #userMacros
2. Copy the .mcr file into that folder.
3. Restart 3ds Max.
4. Go to Customize > Customize User Interface > Toolbars.
5. Category: JasonArts Tools
6. Drag Poly Regularizer onto a toolbar.

MZP install:
1. Drag JasonArts_PolyRegularizer_2026_v1_1.mzp into a 3ds Max viewport.
2. Restart 3ds Max if the toolbar category does not appear immediately.
3. Add the button from Customize > Customize User Interface > Toolbars > JasonArts Tools.

Usage:
1. Use a collapsed Editable Poly object.
2. Go to Polygon sub-object mode.
3. Select the polygons you want to regularize/flatten.
4. Run Poly Regularizer from the JasonArts Tools toolbar category.

Buttons:
1. Flatten + Regularize Boundary
   Flattens selected polys first, then regularizes the boundary.
2. Regularize Boundary Only
   Regularizes the boundary without flattening interior polygons.
3. Flatten Selected Polys Only
   Flattens selected polygons only.

Notes:
- This tool operates on selected polygons and their boundary.
- It is designed for collapsed Editable Poly objects.
- Website / future updates: www.jasonarts.com
