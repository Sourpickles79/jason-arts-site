JasonArts Poly Regularizer 2026 v1.0

For 3ds Max 2026 / Editable Poly objects.

Included files:
- JasonArts_PolyRegularizer_2026_v1_0.mcr
  Toolbar macro version. Place this in your 3ds Max usermacros folder to install manually.

- JasonArts_PolyRegularizer_2026_v1_0.ms
  Source/readable MaxScript version for review or manual running.

- JasonArts_PolyRegularizer_2026_v1_0.mzp
  Optional drag-and-drop installer package. Some studios/IT departments block MZP files.

Manual install:
1. In 3ds Max, open MAXScript Listener and run: getDir #userMacros
2. Copy the .mcr file into that folder.
3. Restart 3ds Max.
4. Go to Customize > Customize User Interface > Toolbars.
5. Category: JasonArts Tools
6. Drag Poly Regularizer onto a toolbar.

Usage:
1. Use a collapsed Editable Poly object.
2. Go to Polygon sub-object mode.
3. Select the polygons you want to regularize/flatten.
4. Run Poly Regularizer from the JasonArts Tools toolbar category.

Notes:
- Button 1 runs flatten selected polys first, then regularizes the boundary.
- Button 2 regularizes the boundary only.
- Button 3 flattens selected polygons only.
