---------------------------------------------------------------------
--  JasonArts Poly Regularizer                                      --
--  version 1.0                                                     --
--  3ds Max 2026 macroScript                                        --
---------------------------------------------------------------------
--  Polygon workflow tool for flattening selected polygon areas     --
--  and regularizing the selected polygon island boundary.           --
--                                                                   --
--  Based on / inspired by GARP's "Edge Loop Regularizer" v1.1       --
--  from April 2011. Modernized and expanded for newer 3ds Max       --
--  polygon-selection workflows.                                     --
---------------------------------------------------------------------

macroScript JasonArts_PolyRegularizer_2026
buttonText:"Poly Regularizer"
category:"JasonArts Tools"
toolTip:"JasonArts Poly Regularizer 2026"
(
	global JasonArts_PolyRegularizer_Rollout

	fn isEditablePolyObj obj =
	(
		obj != undefined and isValidNode obj and classof obj.baseObject == Editable_Poly
	)

	fn clampStrength v =
	(
		amax 0.0 (amin 100.0 v) / 100.0
	)

	fn getSelectedPolyFaces obj =
	(
		try(polyOp.getFaceSelection obj)catch(#{})
	)

	fn getBoundaryEdgesFromFaces obj faceSel =
	(
		local boundaryEdges = #{}
		if faceSel == undefined or faceSel.isEmpty do return boundaryEdges

		local faceEdges = polyOp.getEdgesUsingFace obj faceSel

		for e in faceEdges do
		(
			local edgeFaces = polyOp.getFacesUsingEdge obj e
			local selectedCount = (edgeFaces * faceSel).numberSet

			-- Boundary of the selected polygon island: exactly one selected face touches the edge.
			if selectedCount == 1 do boundaryEdges[e] = true
		)

		boundaryEdges
	)

	fn buildLoopsFromEdges obj edgeSelection =
	(
		local remainingEdges = copy edgeSelection
		local loops = #()

		while not remainingEdges.isEmpty do
		(
			local startEdge = (remainingEdges as array)[1]
			local edgeVerts = polyOp.getEdgeVerts obj startEdge

			local loopVerts = #(edgeVerts[1], edgeVerts[2])
			remainingEdges[startEdge] = false

			local currentVert = edgeVerts[2]

			while true do
			(
				local connectedEdges = (polyOp.getEdgesUsingVert obj currentVert) * remainingEdges
				local connectedCount = connectedEdges.numberSet

				if connectedCount > 1 do return #(false, "Boundary has branching edges. Try a cleaner single polygon island.", loops)

				if connectedCount == 0 then
				(
					if loopVerts[1] != currentVert do return #(false, "Boundary is open. Select a closed polygon area.", loops)
					deleteItem loopVerts loopVerts.count
					exit
				)

				local nextEdge = (connectedEdges as array)[1]
				local nextVerts = (polyOp.getVertsUsingEdge obj nextEdge) as array
				local nextVert = if nextVerts[1] == currentVert then nextVerts[2] else nextVerts[1]

				append loopVerts nextVert
				remainingEdges[nextEdge] = false
				currentVert = nextVert
			)

			append loops loopVerts
		)

		#(true, "OK", loops)
	)

	fn getSafeAxesFromLoop obj loopVerts =
	(
		local count = loopVerts.count
		local center = [0,0,0]

		for v in loopVerts do center += polyOp.getVert obj v
		center /= count

		local normalDir = [0,0,0]
		for i = 1 to count do
		(
			local p1 = polyOp.getVert obj loopVerts[i]
			local p2 = polyOp.getVert obj loopVerts[(mod i count) + 1]
			normalDir += cross (p1 - center) (p2 - center)
		)

		if length normalDir < 0.0001 do return undefined

		local zAxis = normalize normalDir
		local firstVec = (polyOp.getVert obj loopVerts[1]) - center
		local xAxis = firstVec - (zAxis * (dot firstVec zAxis))

		if length xAxis < 0.0001 then
		(
			local temp = if abs(zAxis.z) < 0.9 then [0,0,1] else [0,1,0]
			xAxis = cross temp zAxis
		)

		xAxis = normalize xAxis
		local yAxis = normalize (cross zAxis xAxis)

		#(center, xAxis, yAxis, zAxis)
	)

	fn flattenFacesOnly obj faceSel strengthVal =
	(
		if faceSel == undefined or faceSel.isEmpty do return false

		local vertsBA = polyOp.getVertsUsingFace obj faceSel
		if vertsBA.isEmpty do return false

		local verts = vertsBA as array
		local center = [0,0,0]

		for v in verts do center += polyOp.getVert obj v
		center /= verts.count

		local normalDir = [0,0,0]
		for f in faceSel do
		(
			try(normalDir += polyOp.getFaceNormal obj f)catch()
		)

		-- Fallback normal if the face normal average gets weird.
		if length normalDir < 0.0001 then
		(
			local boundaryEdges = getBoundaryEdgesFromFaces obj faceSel
			local loopResult = buildLoopsFromEdges obj boundaryEdges
			if loopResult[1] and loopResult[3].count > 0 then
			(
				local axes = getSafeAxesFromLoop obj loopResult[3][1]
				if axes != undefined do normalDir = axes[4]
			)
		)

		if length normalDir < 0.0001 do return false

		local n = normalize normalDir
		local s = clampStrength strengthVal

		for v in verts do
		(
			local oldPos = polyOp.getVert obj v
			local dist = dot (oldPos - center) n
			local targetPos = oldPos - (n * dist)
			polyOp.setVert obj v (oldPos + ((targetPos - oldPos) * s))
		)

		true
	)

	fn regularizeLoopOnly obj loopVerts strengthVal =
	(
		local count = loopVerts.count
		if count < 3 do return false

		local axes = getSafeAxesFromLoop obj loopVerts
		if axes == undefined do return false

		local center = axes[1]
		local xAxis = axes[2]
		local yAxis = axes[3]

		local radius = 0.0
		local angleStep = 360.0 / count
		local angleOffset = 0.0

		for i = 1 to count do
		(
			local p = polyOp.getVert obj loopVerts[i]
			local d = p - center
			local lx = dot d xAxis
			local ly = dot d yAxis

			radius += sqrt((lx * lx) + (ly * ly))

			local a = atan2 ly lx
			angleOffset += mod (720 + a - angleStep * i) 360
		)

		radius /= count
		angleOffset /= count

		local s = clampStrength strengthVal

		for i = 1 to count do
		(
			local oldPos = polyOp.getVert obj loopVerts[i]
			local a = angleOffset + angleStep * i
			local targetPos = center + (xAxis * (radius * cos a)) + (yAxis * (radius * sin a))
			polyOp.setVert obj loopVerts[i] (oldPos + ((targetPos - oldPos) * s))
		)

		true
	)

	fn regularizeBoundaryOnly obj faceSel strengthVal =
	(
		if faceSel == undefined or faceSel.isEmpty do return false

		local boundaryEdges = getBoundaryEdgesFromFaces obj faceSel
		if boundaryEdges.isEmpty do return false

		local result = buildLoopsFromEdges obj boundaryEdges
		if result[1] == false then
		(
			messageBox result[2] title:"JasonArts Poly Regularizer"
			return false
		)

		for loop in result[3] do regularizeLoopOnly obj loop strengthVal
		true
	)

	fn runTool mode strengthVal closeAfter =
	(
		if selection.count != 1 then
		(
			messageBox "Select one Editable Poly object." title:"JasonArts Poly Regularizer"
			return false
		)

		local obj = selection[1]

		if not isEditablePolyObj obj then
		(
			messageBox "Object must be collapsed to Editable Poly." title:"JasonArts Poly Regularizer"
			return false
		)

		local faceSel = getSelectedPolyFaces obj

		if faceSel == undefined or faceSel.isEmpty then
		(
			messageBox "Select polygons first." title:"JasonArts Poly Regularizer"
			return false
		)

		undo "JasonArts Poly Regularizer" on
		(
			case mode of
			(
				-- Button 1: intentionally runs Button 3, then Button 2.
				1:
				(
					flattenFacesOnly obj faceSel strengthVal
					regularizeBoundaryOnly obj faceSel strengthVal
				)

				-- Button 2: boundary only. Does not flatten interior.
				2:
				(
					regularizeBoundaryOnly obj faceSel strengthVal
				)

				-- Button 3: flatten selected polygons only. Restored as a standalone operation.
				3:
				(
					flattenFacesOnly obj faceSel strengthVal
				)
			)

			polyOp.setFaceSelection obj faceSel
			update obj
			redrawViews()
		)

		if closeAfter do try(destroyDialog JasonArts_PolyRegularizer_Rollout)catch()
	)

	rollout JasonArts_PolyRegularizer_Rollout "JasonArts Poly Regularizer" width:235 height:155
	(
		spinner spnStrength "Strength:" range:[0,100,100] type:#float fieldwidth:58 align:#left
		checkbox chkClose "Close after run" checked:false align:#left

		button btnBoth "1  Flatten + Regularize Boundary" width:215 height:24 align:#center
		button btnReg "2  Regularize Boundary Only" width:215 height:24 align:#center
		button btnFlat "3  Flatten Selected Polys Only" width:215 height:24 align:#center

		label lblInfo "Select polygons first. Boundary is found from poly selection." width:215 align:#left

		on btnBoth pressed do runTool 1 spnStrength.value chkClose.checked
		on btnReg pressed do runTool 2 spnStrength.value chkClose.checked
		on btnFlat pressed do runTool 3 spnStrength.value chkClose.checked
	)

	on isEnabled return
	(
		selection.count == 1 and isEditablePolyObj selection[1]
	)

	on isVisible return true

	on execute do
	(
		try(destroyDialog JasonArts_PolyRegularizer_Rollout)catch()
		createDialog JasonArts_PolyRegularizer_Rollout style:#(#style_titlebar, #style_sysmenu, #style_toolwindow)
	)
)
